=== WP Mailtrap ===
Author URI: http://ralv.es
Plugin URI: https://github.com/espellcaste/wp-mailtrap
Author: Renato Alves
Tags: mailtrap, wpmail, testing
Requires at least: 3.8
Tested up to: 4.2.2
Contributors: Renato Alves
Donate link: http://ralv.es
Stable tag: 1.0
License: GPL-2.0+

WP Mailtrap is a simple plugin to test emails in WordPress with the Mailtrap API. 

== Description ==

WP Mailtrap is a simple plugin to test emails in WordPress with the Mailtrap API. 

The plugin was created to non-developers who wishes to test if wp_mail is working or to test newsletters or simple text email in WordPress with the simple Mailtrap API.

== Installation ==

1. Upload wp-mailtrap to wp-content/plugins
2. Click "Activate" in the WordPress plugins menu
3. Click WP Mailtrap in the Settings submenu
4. Add Mailtrap inbox info

== Screenshots ==

1. WP Mailtrap Settings

== Changelog ==

= 1.0 = WP Mailtrap plugin with simple options

Initial release.

== Upgrade Notice ==

= 1.0 = Initial release
