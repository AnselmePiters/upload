## WP Mailtrap

WP Mailtrap is a simple plugin to test emails in WordPress with the Mailtrap API. 

The plugin was created to non-developers who wishes to test if wp_mail() is working or to test newsletters or simple text email in WordPress with the simple Mailtrap API.

# Installation

1. Go to the *Plugins* menu and click *Add New*.
2. Search for *WP Mailtrap*.
3. Click *Install Now*.
4. Activate the plugin.

# Screenshots

1. WP Mailtrap Settings
